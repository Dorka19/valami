<?php
define("HOST","localhost");
define("DATABASE","filmimadok");
define("DBUSER","root");
define("DBPASSWORD","");
?>