<?php
	$uri .= $_SERVER['HTTP_REFERER'];
	header('Location: '.$uri.'Filmimadok/Filmimadok.php');
	exit;
?>
